CREATE DATABASE IF NOT EXISTS kid CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE kid;

--------------------------------------------------------
-- TABLE: assessments (kid assessment records)
--------------------------------------------------------
CREATE TABLE assessments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kid_id INT NOT NULL,
    assessor_id INT NOT NULL,
    category VARCHAR(100) NULL,
    score TINYINT UNSIGNED NULL,
    feedback TEXT NULL,
    assessed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX (kid_id),
    INDEX (assessor_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--------------------------------------------------------
-- TABLE: activity_log (audit log)
--------------------------------------------------------
CREATE TABLE activity_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    username VARCHAR(100) NOT NULL,
    role ENUM('admin', 'teacher', 'parent', 'kid') NOT NULL,
    action VARCHAR(255) NOT NULL,
    details TEXT NULL,
    ip_address VARCHAR(45) NULL,
    user_agent TEXT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--------------------------------------------------------
-- TABLE: assessment_grades
--------------------------------------------------------
CREATE TABLE assessment_grades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    assessment_id INT NOT NULL,
    grade CHAR(2) NULL,
    comments TEXT NULL,
    graded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX (assessment_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--------------------------------------------------------
-- TABLE: kid_uploads (kids upload media)
--------------------------------------------------------
CREATE TABLE kid_uploads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kid_id INT NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    description TEXT NULL,
    uploaded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX (kid_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--------------------------------------------------------
-- TABLE: upload_assessments (teachers assess uploaded files)
--------------------------------------------------------
CREATE TABLE upload_assessments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    upload_id INT NOT NULL,
    teacher_id INT NOT NULL,
    grade TINYINT UNSIGNED NOT NULL DEFAULT 0,
    feedback TEXT NULL,
    status ENUM('pending', 'assessed') DEFAULT 'pending',
    talent_status ENUM('Identified', 'Has Potential') NULL,
    assessed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    talent_activity VARCHAR(50) NULL,
    INDEX (upload_id),
    INDEX (teacher_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--------------------------------------------------------
-- TABLE: talent_uploads (user photo/video talent submissions)
--------------------------------------------------------
CREATE TABLE talent_uploads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    file_type ENUM('image', 'video') NOT NULL,
    uploaded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    talent_status ENUM('Pending', 'Approved', 'Rejected', 'Identified') DEFAULT 'Pending',
    INDEX (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--------------------------------------------------------
-- TABLE: users (main login system)
--------------------------------------------------------
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('kid', 'teacher', 'parent', 'admin') NOT NULL,
    parent_id INT NULL,
    email VARCHAR(100) NULL,
    profile_pic VARCHAR(255) DEFAULT 'default.png',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX (username),
    INDEX (parent_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

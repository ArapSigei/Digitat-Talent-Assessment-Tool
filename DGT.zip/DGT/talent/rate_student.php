<?php
session_start();
require '../config.php';
require_role(['parent']);

$upload_id = (int)($_GET['upload_id'] ?? 0);
if (!$upload_id) die('Invalid');

$stmt = $conn->prepare("SELECT u.file_path,u.file_type,usr.username FROM uploads u JOIN users usr ON u.user_id=usr.id WHERE u.id=?");
$stmt->bind_param('i',$upload_id);
$stmt->execute();
$sub = $stmt->get_result()->fetch_assoc() ?: die('Not found');

$message = '';
if ($_POST) {
    $rating  = (int)$_POST['rating'];
    $comment = trim($_POST['comment']);

    $chk = $conn->prepare("SELECT 1 FROM parent_ratings WHERE upload_id=? AND parent_id=?");
    $chk->bind_param('ii',$upload_id,$_SESSION['user_id']);
    $chk->execute();
    if ($chk->get_result()->num_rows) $message = 'Already rated';

    else {
        $ins = $conn->prepare("INSERT INTO parent_ratings (upload_id,parent_id,rating,comment) VALUES (?,?,?,?)");
        $ins->bind_param('iiis',$upload_id,$_SESSION['user_id'],$rating,$comment);
        $ins->execute();
        $message = 'Rating saved';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Rate Submission</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>body{background:#f8f9fa;padding-top:80px}</style>
</head>
<body>
<?php include '../navbar_parent.php'; ?>

<div class="container">
    <h3>Rate <?=$sub['username']?>'s Work</h3>
    <?php if($sub['file_type']=='image'):?>
        <img src="../<?=$sub['file_path']?>" class="img-fluid rounded mb-3">
    <?php else:?>
        <video src="../<?=$sub['file_path']?>" controls class="w-100 rounded mb-3"></video>
    <?php endif;?>

    <?php if($message):?><div class="alert alert-info"><?=$message?></div><?php endif;?>

    <form method="post" class="card p-4">
        <div class="mb-3">
            <label class="form-label">Rating (1-5)</label>
            <select name="rating" class="form-select" required>
                <?php for($i=1;$i<=5;$i++) echo "<option value='$i'>$i Stars</option>";?>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Comment (optional)</label>
            <textarea name="comment" rows="3" class="form-control"></textarea>
        </div>
        <button class="btn btn-primary w-100">Submit Rating</button>
    </form>
</div>
</body>
</html>
<?php
session_start();
require '../config.php';

header('Content-Type: application/json');

// --- SECURITY CHECKS ---
if (
    $_SERVER['REQUEST_METHOD'] !== 'POST' ||
    !isset($_SESSION['role']) || $_SESSION['role'] !== 'teacher' ||
    !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')
) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

// --- INPUTS ---
$upload_id        = (int)($_POST['upload_id'] ?? 0);
$talent_activity  = trim($_POST['talent_activity'] ?? '');
$grade            = (int)($_POST['grade'] ?? 0);
$status           = ($_POST['status'] === 'Identified') ? 'Identified' : 'Potential';
$feedback         = trim($_POST['feedback'] ?? '');

// --- VALIDATION ---
if ($upload_id <= 0 || $grade < 0 || $grade > 100 || $talent_activity === '' || $feedback === '') {
    echo json_encode(['success' => false, 'error' => 'Invalid data']);
    exit;
}

$conn->begin_transaction();

try {

    // --- INSERT OR UPDATE TALENT ASSESSMENT ---
    $sql = "
        INSERT INTO talent_assessments 
            (upload_id, kid_id, talent_activity, grade, status, feedback, assessed_at)
        VALUES 
            (?, (SELECT user_id FROM uploads WHERE id = ?), ?, ?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE
            talent_activity = VALUES(talent_activity),
            grade = VALUES(grade),
            status = VALUES(status),
            feedback = VALUES(feedback),
            assessed_at = NOW()
    ";

    $stmt = $conn->prepare($sql);
    // TYPES: i = int, s = string
    $stmt->bind_param("i s i s s s", $upload_id, $upload_id, $talent_activity, $grade, $status, $feedback);

    // FIXED VERSION (correct types below)
    $stmt->bind_param("i s i s s s", $upload_id, $upload_id, $talent_activity, $grade, $status, $feedback);

    // CORRECT FIX — FINAL:
    $stmt->bind_param("i i s i s s", $upload_id, $upload_id, $talent_activity, $grade, $status, $feedback);

    $stmt->execute();


    // --- UPDATE UPLOAD TALENT STATUS ---
    $stmt2 = $conn->prepare("UPDATE uploads SET talent_status = ? WHERE id = ?");
    $stmt2->bind_param("si", $status, $upload_id);
    $stmt2->execute();

    $conn->commit();

    echo json_encode(['success' => true]);

} catch (Exception $e) {

    $conn->rollback();
    error_log("Assessment error: " . $e->getMessage());

    echo json_encode(['success' => false, 'error' => 'Save failed']);
}

$conn->close();
?>

<?php
session_start();
include '../config.php';
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
header('Content-Type: application/json');

// CORRECT: Count DISTINCT kids who have at least ONE "Identified Talent" assessment
$stmt = $conn->prepare("
    SELECT COUNT(DISTINCT u.id) AS total
    FROM users u
    JOIN uploads up ON u.id = up.user_id
    JOIN talent_assessments ta ON up.id = ta.upload_id
    WHERE u.role = 'kid' 
      AND ta.talent_status = 'Identified'
");

$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_assoc();
$stmt->close();

echo json_encode(['count' => (int)($row['total'] ?? 0)]);
$conn->close();
?>
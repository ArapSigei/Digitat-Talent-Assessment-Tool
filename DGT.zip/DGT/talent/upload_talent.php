<?php
/* --------------------------------------------------------------
   talent/upload_talent.php – FULLY FIXED (no warnings, safe paths)
   -------------------------------------------------------------- */
session_start();
require '../config.php';

// -----------------------------------------------------------------
// 1. Helper: redirect non‑kids (if you don't have require_role)
// -----------------------------------------------------------------
if (empty($_SESSION['user_id']) || $_SESSION['role'] !== 'kid') {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// -----------------------------------------------------------------
// 2. Get kid's REAL username from DB (avoid session warning)
// -----------------------------------------------------------------
$kid_username = 'kid_' . $user_id;   // fallback
$stmt = $conn->prepare("SELECT username FROM users WHERE id = ?");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$stmt->bind_result($db_username);
if ($stmt->fetch()) {
    $kid_username = $db_username;
}
$stmt->close();

// -----------------------------------------------------------------
// 3. BASE URL (for correct redirects in subfolders)
// -----------------------------------------------------------------
$base_url = '/';
$script_name = $_SERVER['SCRIPT_NAME'];
if (strpos($script_name, '/DGT/') !== false)          $base_url = '/DGT/';
elseif (strpos($script_name, '/digital-talent/') !== false) $base_url = '/digital-talent/';
elseif (strpos($script_name, '/KID/') !== false)    $base_url = '/KID/';

// -----------------------------------------------------------------
// 4. PROCESS UPLOAD (only on POST)
// -----------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (empty($_FILES['talent_file']['name'])) {
        $_SESSION['error'] = "Please select a file.";
    } else {
        $file = $_FILES['talent_file'];
        $allowed = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'video/mp4', 'video/webm'];
        $max_size = 50 * 1024 * 1024; // 50MB

        if (!in_array($file['type'], $allowed)) {
            $_SESSION['error'] = "Invalid file type. Only JPG, PNG, GIF, MP4, WEBM allowed.";
        } elseif ($file['size'] > $max_size) {
            $_SESSION['error'] = "File too large. Max 50MB allowed.";
        } else {
            // Safe path: uploads/kids/{user_id}/
            $upload_dir = "../uploads/kids/{$user_id}";
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }

            $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = uniqid('talent_') . '_' . $user_id . '.' . $ext;
            $file_path = "uploads/kids/{$user_id}/{$filename}";   // DB path
            $full_path = "../{$file_path}";                       // Server path

            if (move_uploaded_file($file['tmp_name'], $full_path)) {
                $file_type = strpos($file['type'], 'image') === 0 ? 'image' : 'video';

                $stmt = $conn->prepare("INSERT INTO uploads (user_id, file_path, file_type) VALUES (?, ?, ?)");
                $stmt->bind_param('iss', $user_id, $file_path, $file_type);
                $stmt->execute();
                $stmt->close();

                $_SESSION['success'] = "Talent uploaded successfully!";
                header("Location: {$base_url}talent/view_results.php");
                exit();
            } else {
                $_SESSION['error'] = "Upload failed. Please try again.";
            }
        }
    }

    // If error → fall through to show form
    header("Location: upload_talent.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Upload Talent – Digital Talent</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background:#f8f9fa; padding-top:80px; }
        .navbar-custom { background:linear-gradient(135deg, maroon, #8b0000); }
        .navbar-custom .nav-link, .navbar-custom .navbar-brand { color:#fff !important; }
        .navbar-custom .nav-link:hover { color:#ffd700 !important; }
        .navbar-custom .nav-link.active { background:rgba(255,215,0,.2); border-radius:6px; }
        .card { max-width: 500px; margin: auto; border:none; box-shadow:0 4px 12px rgba(0,0,0,.1); border-radius:12px; }
    </style>
</head>
<body>

<!-- NAVBAR -->
<?php
$current_page = basename($_SERVER['SCRIPT_NAME']);
$kid_name = htmlspecialchars($kid_username);
?>
<nav class="navbar navbar-expand-lg navbar-custom fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="<?= $base_url ?>dashboard.php">
            <i class="bi bi-star-fill text-warning"></i> Digital Talent
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#kidNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="kidNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?= ($current_page === 'dashboard.php') ? 'active' : '' ?>" href="<?= $base_url ?>dashboard.php">
                        <i class="bi bi-house"></i> Home
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= ($current_page === 'upload_talent.php') ? 'active' : '' ?>" href="<?= $base_url ?>talent/upload_talent.php">
                        <i class="bi bi-cloud-upload"></i> Upload
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= ($current_page === 'view_results.php') ? 'active' : '' ?>" href="<?= $base_url ?>talent/view_results.php">
                        <i class="bi bi-trophy"></i> My Results
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= ($current_page === 'profile.php') ? 'active' : '' ?>" href="<?= $base_url ?>profile.php">
                        <i class="bi bi-person"></i> Profile
                    </a>
                </li>
            </ul>
            <ul class="navbar-nav ms-auto">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle"></i> <?= $kid_name ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <li><a class="dropdown-item" href="<?= $base_url ?>profile.php"><i class="bi bi-person"></i> Profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="<?= $base_url ?>logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-5">
    <div class="card shadow">
        <div class="card-header bg-primary text-white text-center">
            <h5 class="mb-0"><i class="bi bi-cloud-upload"></i> Upload Your Talent</h5>
        </div>
        <div class="card-body">
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <?= htmlspecialchars($_SESSION['success']) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php unset($_SESSION['success']); ?>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <?= htmlspecialchars($_SESSION['error']) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label class="form-label">Choose Image or Video</label>
                    <input type="file" name="talent_file" class="form-control" accept="image/*,video/*" required>
                    <small class="text-muted">Max 50MB. JPG, PNG, GIF, MP4, WEBM.</small>
                </div>
                <button type="submit" class="btn btn-success w-100">
                    <i class="bi bi-upload"></i> Upload Talent
                </button>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
if (isset($conn)) $conn->close();
?>
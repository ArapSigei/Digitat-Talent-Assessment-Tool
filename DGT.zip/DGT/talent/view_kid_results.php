<?php
session_start();
require '../config.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'parent') {
    header("Location: ../login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>All Kids Results – Parent View</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
    body { background:#f8f9fa; padding-top:90px; }
    .navbar-custom { background:linear-gradient(135deg, maroon, #8b0000); }
    .navbar-custom .nav-link, .navbar-custom .navbar-brand { color:#fff !important; }
    .navbar-custom .nav-link:hover { color:#ffd700 !important; }
    .table { border-radius:15px; overflow:hidden; box-shadow:0 8px 25px rgba(0,0,0,.1); }
    .table thead { background:#8b0000; color:white; }
    .grade-circle-sm { width:50px; height:50px; border-radius:50%; background:#28a745; color:white; font-weight:bold; display:inline-flex; align-items:center; justify-content:center; font-size:1.1rem; }
    .badge-identified { background:#28a745 !important; }
    .badge-potential { background:#ffc107 !important; color:#212529 !important; }
    .profile-img { width:50px; height:50px; object-fit:cover; border-radius:50%; border:3px solid #8b0000; }
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-custom fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="../dashboard.php">Digital Talent</a>
        <div class="navbar-nav ms-auto">
            <a class="nav-link active" href="#">All Kids Results</a>
            <a class="nav-link" href="../profile.php">Profile</a>
            <a class="nav-link text-danger" href="../logout.php">Logout</a>
        </div>
    </div>
</nav>

<div class="container py-5">
    <h2 class="text-center mb-5 fw-bold text-maroon">
        All Children's Talent Results
    </h2>

    <?php
    $q = "
        SELECT 
            u.id,
            u.username,
            u.profile_pic,
            ta.grade AS latest_grade,
            ta.talent_status,
            COUNT(ta2.id) AS total_assessments,
            AVG(ta2.grade) AS avg_grade
        FROM users u
        LEFT JOIN uploads up ON u.id = up.user_id
        LEFT JOIN talent_assessments ta ON up.id = ta.upload_id 
            AND ta.assessed_at = (
                SELECT MAX(ta3.assessed_at) 
                FROM talent_assessments ta3 
                JOIN uploads up3 ON ta3.upload_id = up3.id 
                WHERE up3.user_id = u.id
            )
        LEFT JOIN talent_assessments ta2 ON up.id = ta2.upload_id
        WHERE u.role = 'kid'
        GROUP BY u.id
        ORDER BY avg_grade DESC, u.username
    ";

    $result = $conn->query($q);
    ?>

    <?php if ($result->num_rows === 0): ?>
        <div class="text-center py-5">
            <h4>No assessments yet</h4>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Profile</th>
                        <th>Kid Name</th>
                        <th>Latest Grade</th>
                        <th>Talent Status</th>
                        <th>Average Grade</th>
                        <th>Total Assessed</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $rank = 1; while ($row = $result->fetch_assoc()): 
                        $latest = (int)($row['latest_grade'] ?? 0);
                        $avg = round((float)($row['avg_grade'] ?? 0), 1);
                        $status = $row['talent_status'] ?? 'Not Assessed';
                        $pic = $row['profile_pic'] && file_exists("../" . $row['profile_pic']) 
                               ? "../" . $row['profile_pic'] 
                               : "../uploads/profiles/default.png";
                    ?>
                        <tr>
                            <td><strong><?= $rank++ ?></strong></td>
                            <td>
                                <img src="<?= $pic ?>" class="profile-img" alt="Profile">
                            </td>
                            <td><strong><?= htmlspecialchars($row['username']) ?></strong></td>
                            <td>
                                <?php if ($latest > 0): ?>
                                    <div class="grade-circle-sm"><?= $latest ?></div>
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($status !== 'Not Assessed'): ?>
                                    <span class="badge fs-6 <?= $status === 'Identified' ? 'badge-identified' : 'badge-potential' ?>">
                                        <?= $status === 'Identified' ? 'Identified Talent' : 'Has Potential' ?>
                                    </span>
                                <?php else: ?>
                                    <span class="text-muted">Not Assessed</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong class="<?= $avg >= 70 ? 'text-success' : 'text-warning' ?>">
                                    <?= $avg > 0 ? $avg : '—' ?>/100
                                </strong>
                            </td>
                            <td>
                                <span class="badge bg-primary">
                                    <?= $row['total_assessments'] ?>
                                </span>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>
<?php
session_start();
require '../config.php';

// Ensure teacher
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'teacher') {
    header("Location: ../login.php");
    exit;
}

$teacher_id = $_SESSION['user_id'];

// Get all student uploads
$q = "
    SELECT 
        u.id AS upload_id, 
        u.user_id,
        u.file_path,
        u.file_type,
        u.talent_status,
        u.uploaded_at,
        us.username,
        ta.grade,
        ta.feedback
    FROM uploads u
    JOIN users us ON us.id = u.user_id
    LEFT JOIN talent_assessments ta ON ta.upload_id = u.id
    ORDER BY u.uploaded_at DESC
";
$res = $conn->query($q);
$pending = [];
$assessed = [];

while ($row = $res->fetch_assoc()) {
    if ($row['grade']) $assessed[] = $row;
    else $pending[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Assess Submissions | Digital Talent</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; padding-top: 80px; }
        .navbar-custom { background: linear-gradient(135deg, maroon, #8b0000); }
        .navbar-custom .nav-link, .navbar-custom .navbar-brand { color: #fff !important; }
        .navbar-custom .nav-link.active { background: rgba(255,215,0,0.2); border-radius: 5px; }
        .card { border: none; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .media { height: 220px; object-fit: cover; border-radius: 8px; }
        .section-title { border-left: 5px solid maroon; padding-left: 10px; margin: 30px 0 15px; }
    </style>
</head>
<body>

<!-- Shared Navbar -->
<nav class="navbar navbar-expand-lg navbar-custom fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="../dashboard.php">Digital Talent</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navBar"><span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse" id="navBar">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="../dashboard.php">Home</a></li>
        <li class="nav-item"><a class="nav-link active" href="assess_talent.php">View Submissions</a></li>
        <li class="nav-item"><a class="nav-link" href="../profile.php">Profile</a></li>
        <li class="nav-item"><a class="nav-link" href="../logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container">

  <!-- Pending Section -->
  <h3 class="section-title text-danger"><i class="bi bi-hourglass-split"></i> Pending Assessments</h3>
  <div class="row">
    <?php if (empty($pending)): ?>
      <p class="text-muted ps-3">No pending submissions 🎉</p>
    <?php else: foreach ($pending as $p): ?>
      <div class="col-md-6 col-lg-4 mb-4">
        <div class="card h-100">
          <?php if ($p['file_type'] === 'image'): ?>
            <img src="../<?= htmlspecialchars($p['file_path']) ?>" class="card-img-top media" alt="Talent">
          <?php else: ?>
            <video src="../<?= htmlspecialchars($p['file_path']) ?>" controls class="card-img-top media"></video>
          <?php endif; ?>
          <div class="card-body">
            <h5 class="card-title text-primary"><?= htmlspecialchars($p['username']) ?></h5>
            <p class="text-muted">Uploaded: <?= date('M j, Y', strtotime($p['uploaded_at'])) ?></p>
            <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#assessModal<?= $p['upload_id'] ?>">Assess</button>
          </div>
        </div>
      </div>

      <!-- Modal -->
      <div class="modal fade" id="assessModal<?= $p['upload_id'] ?>" tabindex="-1">
        <div class="modal-dialog">
          <form class="modal-content" method="POST" action="process_assessment.php">
            <div class="modal-header bg-warning">
              <h5 class="modal-title">Assess <?= htmlspecialchars($p['username']) ?></h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <input type="hidden" name="upload_id" value="<?= $p['upload_id'] ?>">
              <div class="mb-3">
                <label class="form-label">Grade</label>
                <select name="grade" class="form-select" required>
                  <option value="">Select Grade</option>
                  <option>A+</option><option>A</option><option>B+</option>
                  <option>B</option><option>C</option><option>D</option><option>F</option>
                </select>
              </div>
              <div class="mb-3">
                <label class="form-label">Feedback</label>
                <textarea name="feedback" class="form-control" rows="3" placeholder="Enter feedback..." required></textarea>
              </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-success">Submit</button>
            </div>
          </form>
        </div>
      </div>
    <?php endforeach; endif; ?>
  </div>

  <!-- Assessed Section -->
  <h3 class="section-title text-success"><i class="bi bi-check-circle"></i> Assessed Students</h3>
  <div class="row">
    <?php if (empty($assessed)): ?>
      <p class="text-muted ps-3">No assessed students yet.</p>
    <?php else: foreach ($assessed as $a): ?>
      <div class="col-md-6 col-lg-4 mb-4">
        <div class="card h-100 border-success">
          <?php if ($a['file_type'] === 'image'): ?>
            <img src="../<?= htmlspecialchars($a['file_path']) ?>" class="card-img-top media" alt="Talent">
          <?php else: ?>
            <video src="../<?= htmlspecialchars($a['file_path']) ?>" controls class="card-img-top media"></video>
          <?php endif; ?>
          <div class="card-body">
            <h5 class="card-title text-success"><?= htmlspecialchars($a['username']) ?></h5>
            <p><strong>Grade:</strong> <?= htmlspecialchars($a['grade']) ?></p>
            <p><strong>Feedback:</strong> <?= htmlspecialchars($a['feedback']) ?></p>
          </div>
        </div>
      </div>
    <?php endforeach; endif; ?>
  </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</body>
</html>

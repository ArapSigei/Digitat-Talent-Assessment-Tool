<?php
session_start();
require '../config.php';
require_role(['kid']);

$user_id = $_SESSION['user_id'];

if (!isset($_GET['id'])) {
    header("Location: view_kid_results.php");
    exit();
}

$upload_id = intval($_GET['id']);

// Get file path for deletion
$stmt = $conn->prepare("SELECT file_path FROM uploads WHERE id=? AND user_id=?");
$stmt->bind_param("ii", $upload_id, $user_id);
$stmt->execute();
$stmt->bind_result($file_path);
if ($stmt->fetch()) {
    $stmt->close();

    // Delete the record
    $del = $conn->prepare("DELETE FROM uploads WHERE id=? AND user_id=?");
    $del->bind_param("ii", $upload_id, $user_id);
    $del->execute();

    // Delete file from server
    $full_path = realpath("../" . $file_path);
    if ($full_path && file_exists($full_path)) {
        unlink($full_path);
    }
}
header("Location: view_kid_results.php?msg=deleted");
exit();
?>

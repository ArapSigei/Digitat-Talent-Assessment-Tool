<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require '../config.php';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    header("Location: ../login.php"); exit;
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'] ?? 'Student';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>My Talent Results</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
    body { background:#f8f9fa; padding-top:90px; }
    .navbar-custom { background:linear-gradient(135deg, maroon, #8b0000); box-shadow:0 4px 12px rgba(0,0,0,.2); }
    .navbar-custom .nav-link,.navbar-custom .navbar-brand { color:#fff !important; }
    .navbar-custom .nav-link:hover { color:#ffd700 !important; }
    .card { position:relative; border:none; box-shadow:0 6px 20px rgba(0,0,0,.1); border-radius:18px; overflow:hidden; }
    .media { height:260px; object-fit:cover; }
    .grade-circle { width:110px; height:110px; border-radius:50%; background:#28a745; color:white; font-size:2.5rem; font-weight:bold; display:flex; align-items:center; justify-content:center; margin:0 auto 15px; box-shadow:0 4px 15px rgba(40,167,69,.4); }
    .progress { height:14px; border-radius:7px; }
    .badge-identified { background:#28a745 !important; }
    .badge-potential { background:#ffc107 !important; color:#212529 !important; }
    .delete-btn { position:absolute; top:10px; right:10px; z-index:10; background:rgba(220,53,69,.9); border:none; width:40px; height:40px; border-radius:50%; }
    .delete-btn:hover { background:#dc3545; transform:scale(1.1); }
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-custom fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="../dashboard.php">Digital Talent</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="nav">
            <ul class="navbar-nav me-auto">
                <li><a class="nav-link" href="../dashboard.php">Home</a></li>
                <li><a class="nav-link" href="upload_talent.php">Upload</a></li>
                <li><a class="nav-link active" href="#">My Results</a></li>
                <li><a class="nav-link" href="../profile.php">Profile</a></li>
            </ul>
            <div class="navbar-nav ms-auto dropdown">
                <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><?=htmlspecialchars($username)?></a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="../profile.php">Profile</a></li>
                    <li><a class="dropdown-item text-danger" href="../logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>

<div class="container py-5">
    <h2 class="text-center mb-5 fw-bold text-maroon">My Talent Results</h2>

    <?php
    $stmt = $conn->prepare("SELECT u.id, u.file_path, u.file_type, u.uploaded_at,
                                   ta.grade, ta.talent_status, ta.feedback, ta.status AS assessed, ta.assessed_at
                            FROM uploads u
                            LEFT JOIN talent_assessments ta ON u.id = ta.upload_id
                            WHERE u.user_id = ?
                            ORDER BY u.uploaded_at DESC");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $res = $stmt->get_result();
    ?>

    <?php if ($res->num_rows === 0): ?>
        <div class="text-center py-5">
            <h4>No Uploads Yet</h4>
            <a href="upload_talent.php" class="btn btn-primary btn-lg">Upload Your Talent</a>
        </div>
    <?php else: ?>
        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            <?php while ($row = $res->fetch_assoc()):
                $grade = (int)($row['grade'] ?? 0);
                $isAssessed = $row['assessed'] === 'assessed';
                $statusBadge = $row['talent_status'] === 'Identified' ? 'badge-identified' : 'badge-potential';
                $statusText = $row['talent_status'] === 'Identified' ? 'Identified Talent' : 'Has Potential';
            ?>
                <div class="col">
                    <div class="card h-100">

                        <!-- RED DELETE BUTTON (BACK!) -->
                        <button class="btn btn-danger delete-btn shadow" onclick="deleteUpload(<?= $row['id'] ?>)">
                            <i class="bi bi-trash-fill"></i>
                        </button>

                        <!-- MEDIA -->
                        <?php if ($row['file_type'] === 'image'): ?>
                            <img src="../<?=htmlspecialchars($row['file_path'])?>" class="card-img-top media" alt="Talent">
                        <?php else: ?>
                            <video src="../<?=htmlspecialchars($row['file_path'])?>" controls class="card-img-top media"></video>
                        <?php endif; ?>

                        <div class="card-body text-center">
                            <?php if ($isAssessed): ?>
                                <div class="grade-circle"><?= $grade ?></div>
                                <div class="progress mb-3">
                                    <div class="progress-bar <?= $grade >= 70 ? 'bg-success' : 'bg-warning' ?>" style="width:<?= $grade ?>%"></div>
                                </div>
                                <span class="badge <?= $statusBadge ?> fs-5 px-4 py-2"><?= $statusText ?></span>

                                <?php if ($row['feedback']): ?>
                                    <div class="alert alert-light small mt-3">
                                        <strong>Feedback:</strong><br><?= nl2br(htmlspecialchars($row['feedback'])) ?>
                                    </div>
                                <?php endif; ?>

                                <small class="text-muted d-block mt-3">
                                    Assessed: <?= date('d M Y', strtotime($row['assessed_at'])) ?>
                                </small>
                            <?php else: ?>
                                <div class="py-5">
                                    <i class="bi bi-hourglass-split display-4 text-warning"></i>
                                    <p class="mt-3 text-warning fw-bold fs-5">Awaiting Assessment</p>
                                </div>
                            <?php endif; ?>

                            <hr class="my-3">
                            <small class="text-muted">Uploaded: <?= date('d M Y', strtotime($row['uploaded_at'])) ?></small>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    <?php endif; ?>
</div>

<!-- SweetAlert2 + Delete Function -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
async function deleteUpload(id) {
    const { isConfirmed } = await Swal.fire({
        title: 'Delete this upload?',
        text: "You won't be able to recover it!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, delete it!'
    });

    if (isConfirmed) {
        const res = await fetch('delete_upload.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'upload_id=' + id
        });
        const data = await res.json();
        if (data.success) {
            Swal.fire('Deleted!', 'Your upload has been removed.', 'success')
                .then(() => location.reload());
        } else {
            Swal.fire('Error', data.error || 'Failed to delete', 'error');
        }
    }
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $stmt->close(); $conn->close(); ?>
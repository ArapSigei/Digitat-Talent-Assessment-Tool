// talent/talent.js

document.addEventListener('DOMContentLoaded', () => {
    console.log('Talent module loaded ✅');
    
    // Example: auto preview of uploaded file
    const fileInput = document.querySelector('input[name="file"]');
    const preview = document.createElement('div');

    if (fileInput) {
        fileInput.parentNode.appendChild(preview);
        fileInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            preview.innerHTML = '';
            if (file) {
                const url = URL.createObjectURL(file);
                if (file.type.startsWith('image/')) {
                    preview.innerHTML = `<img src="${url}" class="img-fluid mt-2 rounded">`;
                } else if (file.type.startsWith('video/')) {
                    preview.innerHTML = `<video src="${url}" controls class="mt-2 w-100 rounded"></video>`;
                }
            }
        });
    }
});

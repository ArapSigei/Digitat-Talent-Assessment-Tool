<?php
session_start();
require '../config.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'teacher') {
    header("Location: ../login.php"); 
    exit;
}

$teacher_id = $_SESSION['user_id'];
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Assess Talent | Teacher Panel</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
    body { background:#f8f9fa; padding-top:80px; }
    .navbar-custom { background:linear-gradient(135deg, maroon, #8b0000); }
    .navbar-custom .nav-link, .navbar-custom .navbar-brand { color:#fff !important; }
    .card { border:none; box-shadow:0 4px 15px rgba(0,0,0,.1); border-radius:15px; overflow:hidden; }
    .card:hover { transform:scale(1.03); transition:0.3s; }
    .media { height:220px; object-fit:cover; }
    .form-label { font-size:0.9rem; font-weight:600; }
    .cursor-pointer { cursor:pointer; }
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-custom fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="../dashboard.php">Teacher Panel</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="nav">
            <ul class="navbar-nav ms-auto">
                <li><a class="nav-link" href="../dashboard.php">Home</a></li>
                <li><a class="nav-link active" href="#">Assess Talent</a></li>
                <li><a class="nav-link" href="../profile.php">Profile</a></li>
                <li><a class="nav-link text-danger" href="../logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container">
    <h2 class="my-4 text-center fw-bold">Talent Assessment Panel</h2>
    
    <div class="alert alert-success d-none" id="successAlert">
        Assessment saved successfully!
    </div>

    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card text-center p-4 bg-warning text-white cursor-pointer" id="showPending">
                <h4>Pending</h4>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card text-center p-4 bg-success text-white cursor-pointer" id="showAssessed">
                <h4>Assessed</h4>
            </div>
        </div>
    </div>

    <!-- PENDING ASSESSMENTS -->
    <div id="pendingSection">
        <h4 class="mb-3 text-warning">Pending Assessments</h4>
        <div class="row">
            <?php
            $stmt = $conn->prepare("
                SELECT 
                    u.id AS upload_id,
                    u.file_path,
                    u.file_type,
                    u.uploaded_at,
                    usr.username
                FROM uploads u
                JOIN users usr ON u.user_id = usr.id
                LEFT JOIN talent_assessments ta ON ta.upload_id = u.id
                WHERE ta.upload_id IS NULL
                ORDER BY u.uploaded_at DESC
            ");
            $stmt->execute();
            $result = $stmt->get_result();   // ← THIS IS THE CORRECT VARIABLE

            if ($result->num_rows === 0):    // ← NOW USING $result
            ?>
                <p class="text-center text-muted py-5">No pending submissions</p>
            <?php 
            else: 
                while ($r = $result->fetch_assoc()): 
            ?>
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="card">
                        <?php if ($r['file_type'] === 'image'): ?>
                            <img src="../<?=htmlspecialchars($r['file_path'])?>" class="card-img-top media" alt="Talent">
                        <?php else: ?>
                            <video src="../<?=htmlspecialchars($r['file_path'])?>" controls class="card-img-top media"></video>
                        <?php endif; ?>

                        <div class="card-body">
                            <h6 class="fw-bold"><?=htmlspecialchars($r['username'])?></h6>
                            <small class="text-muted">Uploaded: <?=date('d M Y', strtotime($r['uploaded_at']))?></small>

                            <form class="assessment-form mt-3" data-upload-id="<?= $r['upload_id'] ?>">
                                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                                <input type="hidden" name="upload_id" value="<?= $r['upload_id'] ?>">

                                <div class="mb-3">
                                    <label class="form-label fw-bold text-primary">Grade (0–100)</label>
                                    <input type="number" name="grade" class="form-control form-control-lg text-center" 
                                           min="0" max="100" placeholder="e.g. 87" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label fw-bold text-success">Talent Status</label>
                                    <select name="talent_status" class="form-select" required>
                                        <option value="">Select Status</option>
                                        <option value="Identified">Identified Talent</option>
                                        <option value="Has Potential">Has Potential</option>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Feedback (optional)</label>
                                    <textarea name="feedback" class="form-control" rows="3" 
                                              placeholder="Great performance! Keep practicing..."></textarea>
                                </div>

                                <button type="submit" class="btn btn-success btn-lg w-100">
                                    Save Assessment
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php 
                endwhile; 
            endif; 
            $stmt->close();
            ?>
        </div>
    </div>

    <!-- ASSESSED SECTION -->
    <div id="assessedSection" style="display:none;">
        <h4 class="mb-3 text-success">Assessed Students</h4>
        <div class="row" id="assessedContainer">
            <div class="text-center"><div class="spinner-border"></div></div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('showPending').onclick = () => {
    document.getElementById('pendingSection').style.display = 'block';
    document.getElementById('assessedSection').style.display = 'none';
};

document.getElementById('showAssessed').onclick = () => {
    document.getElementById('pendingSection').style.display = 'none';
    document.getElementById('assessedSection').style.display = 'block';
    if (document.getElementById('assessedContainer').innerHTML.includes('spinner')) {
        loadAssessed();
    }
};

document.querySelectorAll('.assessment-form').forEach(f => {
    f.onsubmit = async e => {
        e.preventDefault();
        const btn = f.querySelector('button');
        btn.disabled = true; 
        btn.innerHTML = 'Saving...';

        const res = await fetch('save_assessment.php', { 
            method: 'POST', 
            body: new FormData(f) 
        });
        const data = await res.json();

        if (data.success) {
            document.getElementById('successAlert').classList.remove('d-none');
            f.closest('.col-md-6, .col-lg-4').remove();
            setTimeout(() => document.getElementById('successAlert').classList.add('d-none'), 3000);
        } else {
            alert('Error: ' + (data.error || 'Try again'));
        }
        btn.disabled = false; 
        btn.innerHTML = 'Save Assessment';
    };
});

async function loadAssessed() {
    const c = document.getElementById('assessedContainer');
    c.innerHTML = '<div class="text-center"><div class="spinner-border"></div></div>';
    c.innerHTML = await (await fetch('ajax_assessed.php')).text();
}
</script>
</body>
</html>
<?php $conn->close(); ?>
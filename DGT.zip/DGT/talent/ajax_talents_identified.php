<?php
session_start();
require '../config.php';

if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['admin', 'teacher'])) {
    echo "<p class='text-danger'>Access denied.</p>";
    exit;
}

$q = "
    SELECT DISTINCT u.username, u.profile_pic, ta.grade, ta.assessed_at
    FROM users u
    JOIN uploads up ON u.id = up.user_id
    JOIN talent_assessments ta ON up.id = ta.upload_id
    WHERE u.role = 'kid' AND ta.talent_status = 'Identified'
    ORDER BY ta.assessed_at DESC
";

$result = $conn->query($q);

if ($result->num_rows === 0): ?>
    <p class="text-center text-muted py-4">No students with <strong>Identified Talent</strong> yet.</p>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-sm table-hover align-middle">
            <thead class="table-warning">
                <tr>
                    <th>#</th>
                    <th>Student</th>
                    <th>Grade</th>
                    <th>Identified On</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; while ($row = $result->fetch_assoc()): 
                    $pic = $row['profile_pic'] ? "../" . $row['profile_pic'] : "../uploads/profiles/default.png";
                ?>
                    <tr>
                        <td><strong><?= $i++ ?></strong></td>
                        <td>
                            <img src="<?= htmlspecialchars($pic) ?>" width="40" height="40" class="rounded-circle me-2" onerror="this.src='../uploads/profiles/default.png'">
                            <strong><?= htmlspecialchars($row['username']) ?></strong>
                        </td>
                        <td>
                            <span class="badge bg-success fs-6"><?= $row['grade'] ?>/100</span>
                        </td>
                        <td><?= date('d M Y', strtotime($row['assessed_at'])) ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <div class="alert alert-success text-center mt-3">
        <strong>Congratulations!</strong> These students have been officially <strong>Identified</strong> as having exceptional talent.
    </div>
<?php endif; ?>
<?php $conn->close(); ?>
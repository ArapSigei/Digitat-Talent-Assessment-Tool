<?php
session_start();
require '../config.php';

if (!isset($_SESSION['user_id']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$upload_id = (int)$_POST['upload_id'];
$user_id   = $_SESSION['user_id'];

// Security: only delete own upload
$stmt = $conn->prepare("SELECT file_path FROM uploads WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $upload_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'error' => 'Not found']);
    exit;
}

$row = $result->fetch_assoc();

// Delete assessment first (if exists)
$conn->query("DELETE FROM talent_assessments WHERE upload_id = $upload_id");

// Delete the upload record
$conn->query("DELETE FROM uploads WHERE id = $upload_id");

// Delete the actual file
if (file_exists('../' . $row['file_path'])) {
    unlink('../' . $row['file_path']);
}

echo json_encode(['success' => true]);
?>
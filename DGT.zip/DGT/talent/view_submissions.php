<?php
session_start();
require '../config.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'teacher') {
    header("Location: ../login.php");
    exit;
}
$teacher_name = $_SESSION['username'] ?? 'Teacher';
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>View Submissions</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
body { background:#f8f9fa; padding-top:80px; }
.navbar-custom { background:linear-gradient(135deg, maroon, #8b0000); }
.navbar-custom .nav-link, .navbar-custom .navbar-brand { color:#fff !important; }
.navbar-custom .nav-link:hover, .navbar-custom .nav-link.active { color:#ffd700 !important; }
.card-main { border:none; box-shadow:0 4px 15px rgba(0,0,0,.1); border-radius:12px; margin-bottom:30px; }
.card-main .card-body { max-height: 500px; overflow-y: auto; }
.submission-card { border:none; box-shadow:0 2px 8px rgba(0,0,0,.08); border-radius:8px; margin-bottom:15px; }
.submission-card img, .submission-card video { border-radius: 0.5rem 0.5rem 0 0; }
.section-title { font-weight:bold; color:maroon; }
</style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand fw-bold" href="../dashboard.php"><i class="bi bi-mortarboard-fill"></i> Teacher Panel</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link <?= $current_page=='dashboard.php'?'active':'' ?>" href="../dashboard.php"><i class="bi bi-house-door"></i> Home</a></li>
        <li class="nav-item"><a class="nav-link <?= $current_page=='view_submissions.php'?'active':'' ?>" href="#"><i class="bi bi-eye"></i> View Submissions</a></li>
        <li class="nav-item"><a class="nav-link" href="../profile.php"><i class="bi bi-person"></i> Profile</a></li>
      </ul>
      <ul class="navbar-nav">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown"><i class="bi bi-person-circle"></i> <?= htmlspecialchars($teacher_name) ?></a>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item" href="../profile.php"><i class="bi bi-person"></i> Profile</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" href="../logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>

<div class="container mt-5 pt-3">
  <h2 class="text-center mb-4"><i class="bi bi-folder2-open"></i> kid Submissions</h2>

  <div class="row">
    <!-- Pending Assessments Card -->
    <div class="col-md-6">
      <div class="card card-main">
        <div class="card-header bg-warning text-white text-center">
          <h4><i class="bi bi-hourglass-split"></i> Pending Assessments</h4>
        </div>
        <div class="card-body">
          <?php
          $q = "SELECT u.id AS upload_id, u.file_path, u.file_type, u.uploaded_at, usr.username
                FROM uploads u
                JOIN users usr ON u.user_id = usr.id
                LEFT JOIN talent_assessments ta ON ta.upload_id = u.id
                WHERE ta.id IS NULL
                ORDER BY u.uploaded_at DESC";
          $res = $conn->query($q);
          if($res->num_rows===0): ?>
            <div class="text-center py-5 text-muted">
              <i class="bi bi-inbox display-1"></i>
              <p>No pending assessments.</p>
            </div>
          <?php else:
            while($r=$res->fetch_assoc()): ?>
              <div class="card submission-card">
                <?php if($r['file_type']=='image'): ?>
                  <img src="../<?= htmlspecialchars($r['file_path']) ?>" class="card-img-top" style="height:180px; object-fit:cover;">
                <?php else: ?>
                  <video src="../<?= htmlspecialchars($r['file_path']) ?>" controls class="card-img-top" style="height:180px; object-fit:cover;"></video>
                <?php endif; ?>
                <div class="card-body">
                  <h6 class="fw-bold"><?= htmlspecialchars($r['username']) ?></h6>
                  <small class="text-muted"><i class="bi bi-calendar3"></i> <?= date('M j, Y', strtotime($r['uploaded_at'])) ?></small>
                  <a href="assess_talent.php?upload_id=<?= urlencode($r['upload_id']) ?>" class="btn btn-primary btn-sm mt-2 w-100">
                    <i class="bi bi-check-circle"></i> Assess
                  </a>
                </div>
              </div>
          <?php endwhile; endif; ?>
        </div>
      </div>
    </div>

    <!-- Assessed Students Card -->
    <div class="col-md-6">
      <div class="card card-main">
        <div class="card-header bg-success text-white text-center">
          <h4><i class="bi bi-check2-circle"></i> Assessed kids</h4>
        </div>
        <div class="card-body">
          <?php
          $q2 = "SELECT usr.username, u.file_path, u.file_type, ta.grade, ta.feedback, ta.assessed_at
                 FROM talent_assessments ta
                 JOIN uploads u ON ta.upload_id = u.id
                 JOIN users usr ON u.user_id = usr.id
                 ORDER BY ta.assessed_at DESC";
          $res2 = $conn->query($q2);
          if($res2->num_rows===0): ?>
            <div class="text-center py-5 text-muted">
              <i class="bi bi-inbox display-1"></i>
              <p>No assessed students yet.</p>
            </div>
          <?php else:
            while($r=$res2->fetch_assoc()): ?>
              <div class="card submission-card">
                <?php if($r['file_type']=='image'): ?>
                  <img src="../<?= htmlspecialchars($r['file_path']) ?>" class="card-img-top" style="height:180px; object-fit:cover;">
                <?php else: ?>
                  <video src="../<?= htmlspecialchars($r['file_path']) ?>" controls class="card-img-top" style="height:180px; object-fit:cover;"></video>
                <?php endif; ?>
                <div class="card-body">
                  <h6 class="fw-bold"><?= htmlspecialchars($r['username']) ?></h6>
                  <span class="badge bg-success"><?= htmlspecialchars($r['grade']) ?></span>
                  <p class="mt-2 small"><strong>Feedback:</strong> <?= htmlspecialchars($r['feedback']) ?></p>
                  <small class="text-muted"><i class="bi bi-calendar3"></i> <?= date('M j, Y', strtotime($r['assessed_at'])) ?></small>
                </div>
              </div>
          <?php endwhile; endif; ?>
        </div>
      </div>
    </div>

  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>

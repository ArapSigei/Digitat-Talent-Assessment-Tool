<?php
session_start();
require '../config.php';
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['admin', 'teacher'])) {
    http_response_code(403);
    exit('<p class="text-danger text-center">Unauthorized</p>');
}

$students = [];
try {
    $stmt = $conn->prepare("SELECT id, username, email, created_at FROM users WHERE role = 'kid' ORDER BY username");
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $students[] = $row;
    }
    $stmt->close();
} catch (Exception $e) {
    error_log("ajax_students error: " . $e->getMessage());
    echo '<p class="text-danger">Error loading students.</p>';
    exit;
}
?>

<div class="table-responsive">
    <table class="table table-striped table-hover align-middle">
        <thead class="table-primary">
            <tr>
                <th>#</th>
                <th>kid Name</th>
                <th>Email</th>
                <th>Joined</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($students)): ?>
                <?php foreach ($students as $i => $s): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td><strong><?= htmlspecialchars($s['username']) ?></strong></td>
                        <td><?= htmlspecialchars($s['email']) ?></td>
                        <td><?= date('M j, Y', strtotime($s['created_at'])) ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" class="text-center text-muted py-4">
                        <i class="fas fa-users-slash fa-2x d-block mb-2"></i>
                        No kid found.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php $conn->close(); ?>
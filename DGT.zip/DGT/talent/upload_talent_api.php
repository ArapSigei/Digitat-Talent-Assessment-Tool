<?php
session_start();
require '../config.php';
require_role(['kid']);

header('Content-Type: application/json');

if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['status'=>'error','message'=>'No file uploaded']);
    exit;
}

$file = $_FILES['file'];
$maxSize = 50 * 1024 * 1024;               // 50 MB
$allowed = ['image/jpeg','image/png','image/gif','video/mp4','video/quicktime','video/x-msvideo'];
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime  = finfo_file($finfo, $file['tmp_name']);
finfo_close($finfo);

if ($file['size'] > $maxSize || !in_array($mime, $allowed)) {
    echo json_encode(['status'=>'error','message'=>'Invalid file type/size']);
    exit;
}

$dir = '../uploads/talent/';
if (!is_dir($dir)) mkdir($dir, 0755, true);

$ext = pathinfo($file['name'], PATHINFO_EXTENSION);
$name = time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
$path = $dir . $name;
$relative = 'uploads/talent/' . $name;

if (!move_uploaded_file($file['tmp_name'], $path)) {
    echo json_encode(['status'=>'error','message'=>'Upload failed']);
    exit;
}

$type = str_starts_with($mime, 'video') ? 'video' : 'image';

$stmt = $conn->prepare("INSERT INTO uploads (user_id, file_path, file_type) VALUES (?,?,?)");
$stmt->bind_param('iss', $_SESSION['user_id'], $relative, $type);
$stmt->execute();

echo json_encode(['status'=>'success','message'=>'Talent uploaded!']);
<?php
session_start();
require '../config.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || 
    !isset($_SESSION['role']) || $_SESSION['role'] !== 'teacher' ||
    !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$upload_id     = (int)$_POST['upload_id'];
$grade         = (int)$_POST['grade'];           // ← numeric 0–100
$talent_status = $_POST['talent_status'];        // ← Identified or Has Potential
$feedback      = trim($_POST['feedback'] ?? '');

if ($grade < 0 || $grade > 100) {
    echo json_encode(['success' => false, 'error' => 'Grade must be 0–100']);
    exit;
}

try {
    $stmt = $conn->prepare("INSERT INTO talent_assessments 
        (upload_id, teacher_id, grade, talent_status, feedback, status, assessed_at)
        VALUES (?, ?, ?, ?, ?, 'assessed', NOW())
        ON DUPLICATE KEY UPDATE
        grade = VALUES(grade),
        talent_status = VALUES(talent_status),
        feedback = VALUES(feedback),
        status = 'assessed',
        assessed_at = NOW()");

    $stmt->bind_param("iiiss", $upload_id, $_SESSION['user_id'], $grade, $talent_status, $feedback);
    $stmt->execute();

    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Failed to save']);
}
?>
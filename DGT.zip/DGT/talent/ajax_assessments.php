<?php
session_start();
require '../config.php';
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['admin', 'teacher'])) {
    http_response_code(403);
    exit('<p class="text-danger text-center">Unauthorized</p>');
}

$assessments = [];
try {
    $stmt = $conn->prepare("
        SELECT u.username, ta.grade, ta.talent_activity, ta.feedback, ta.assessed_at, up.file_path, up.file_type
        FROM talent_assessments ta
        JOIN uploads up ON ta.upload_id = up.id
        JOIN users u ON up.user_id = u.id
        WHERE u.role = 'kid'
        ORDER BY ta.assessed_at DESC
    ");
    $stmt->execute();
    $res = $stmt->get_result();
    while ($r = $res->fetch_assoc()) {
        $r['grade_num'] = match($r['grade']) {
            'A+' => 95, 'A' => 85, 'B+' => 75, 'B' => 65,
            'C' => 55, 'D' => 45, 'F' => 35, default => 0
        };
        $r['feedback'] = $r['feedback'] ? nl2br(htmlspecialchars($r['feedback'])) : '<em class="text-muted">—</em>';
        $r['assessed_at'] = date('M j, Y g:i A', strtotime($r['assessed_at']));
        $r['file_icon'] = $r['file_type'] === 'image' ? 'image' : 'video';
        $r['file_preview'] = $r['file_path'] ? '../../' . htmlspecialchars($r['file_path']) : '';
        $assessments[] = $r;
    }
    $stmt->close();
} catch (Exception $e) {
    error_log("ajax_assessments error: " . $e->getMessage());
    echo '<p class="text-danger">Error loading assessments.</p>';
    exit;
}
?>

<div class="table-responsive">
    <table class="table table-sm table-hover align-middle">
        <thead class="table-success">
            <tr>
                <th>#</th>
                <th>Student</th>
                <th>Activity</th>
                <th>Grade</th>
                <th>Score</th>
                <th>Feedback</th>
                <th>Date</th>
                <th>Preview</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($assessments)): ?>
                <?php foreach ($assessments as $i => $a): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td><strong><?= htmlspecialchars($a['username']) ?></strong></td>
                        <td><span class="badge bg-primary"><?= htmlspecialchars($a['talent_activity']) ?></span></td>
                        <td>
                            <span class="badge bg-<?= $a['grade_num'] >= 90 ? 'success' : ($a['grade_num'] >= 70 ? 'warning' : 'danger') ?>">
                                <?= $a['grade'] ?>
                            </span>
                        </td>
                        <td><strong><?= $a['grade_num'] ?></strong></td>
                        <td class="small"><?= $a['feedback'] ?></td>
                        <td><?= $a['assessed_at'] ?></td>
                        <td>
                            <?php if ($a['file_preview']): ?>
                                <a href="<?= $a['file_preview'] ?>" target="_blank">
                                    <i class="fas fa-<?= $a['file_icon'] ?> text-primary"></i>
                                </a>
                            <?php else: ?>
                                <span class="text-muted">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="8" class="text-center text-muted py-4">
                        <i class="fas fa-inbox fa-2x d-block mb-2"></i>
                        No assessments yet.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php $conn->close(); ?>
<?php
session_start();
include '../config.php';

// Only allow kids
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'kid') {
    header("Location: ../login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Upload Talent</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Upload Your Talent</h2>
    <form id="uploadForm" action="upload_talent.php" method="post" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="file">Select File (Image/Video)</label>
            <input type="file" name="file" class="form-control" id="file" required>
        </div>
        <button type="submit" class="btn btn-primary">Upload</button>
    </form>

    <div id="message" class="mt-3"></div>
</div>

<script>
const form = document.getElementById('uploadForm');
form.addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(form);

    fetch('upload_talent.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        document.getElementById('message').innerHTML = data.status === 'success' 
            ? `<div class="alert alert-success">${data.message}</div>`
            : `<div class="alert alert-danger">${data.message}</div>`;
        if(data.status === 'success') form.reset();
    })
    .catch(err => {
        document.getElementById('message').innerHTML = `<div class="alert alert-danger">Upload failed</div>`;
    });
});
</script>
</body>
</html>
